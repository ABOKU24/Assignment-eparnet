function y = myFunction2(x)

y = x - 2*sin(x);

end