clc;
clear;

x0 = 1;
x1 = 2;

tol = 1e-6;
maxIter = 100;

i = 0;
error = Inf;

fprintf('Iteration\t x\t\t Error\n');

while error >= tol && i < maxIter

    i = i + 1;

    f0 = myFunction2(x0);
    f1 = myFunction2(x1);

    x2 = x1 - (f1*(x1-x0))/(f1-f0);

    error = abs(x2-x1);

    fprintf('%d\t\t %.8f\t %.8f\n', i, x2, error);

    x0 = x1;
    x1 = x2;

end

fprintf('\nRoot = %.8f\n', x1);
fprintf('Number of iterations = %d\n', i);