clc;
clear;

x0 = 1;
x1 = 2;

tol = 1e-6;
maxIter = 100;

fprintf('Iteration\t x\t\t Error\n');

for i = 1:maxIter

    f0 = myFunction2(x0);
    f1 = myFunction2(x1);

    x2 = x1 - (f1*(x1-x0))/(f1-f0);

    error = abs(x2-x1);

    fprintf('%d\t\t %.8f\t %.8f\n', i, x2, error);

    if error < tol
        break;
    end

    x0 = x1;
    x1 = x2;

end

fprintf('\nRoot = %.8f\n', x2);
fprintf('Number of iterations = %d\n', i);