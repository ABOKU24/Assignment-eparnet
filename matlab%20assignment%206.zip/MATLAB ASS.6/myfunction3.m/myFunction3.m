function dydx = myFunction3(x,y)

dydx = sin(3*x) - 2*y;

end