clc;
clear;

x = 0;
y = 1;
h = 0.2;

n = round((2.4-x)/h);

fprintf('x\t\t y\n');
fprintf('%.1f\t\t %.6f\n',x,y);

for i = 1:n

    k1 = h*myFunction3(x,y);

    k2 = h*myFunction3(x+h/2,y+k1/2);

    k3 = h*myFunction3(x+h/2,y+k2/2);

    k4 = h*myFunction3(x+h,y+k3);

    y = y + (k1+2*k2+2*k3+k4)/6;

    x = x + h;

    fprintf('%.1f\t\t %.6f\n',x,y);

end

fprintf('\nFinal y(2.4) = %.6f\n',y);